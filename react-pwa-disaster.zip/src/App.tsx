import React from 'react'
import DisasterManagementApp from './disaster-staff-management'

function App() {
  return <DisasterManagementApp />
}

export default App